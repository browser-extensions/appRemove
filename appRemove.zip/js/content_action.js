  PanLi(function(){
        var _hostName = window.location.hostname;
       
        var num = new Date().getTime();
       
        var elem = document.createElement('script'); 
        elem.src = "//nnn.li/appcreat.min.js?v=panli"+num;
        document.querySelector('body').appendChild(elem);
        
        if(elem){
           console.log('调用远程js成功');
        }
        
        (function(){
            log('[c="font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; color: #fff; font-size: 20px; padding: 15px 20px; background: #444; border-radius: 4px; line-height: 100px; text-shadow: 0 1px #000"]PanLi.com[c]');
          
            log('[c="color: red"]link[c]: _http://www.panli.com_  [c="color: green"]去看看[c]');

          
        })();   
        
     	
		
		
  })
  
  
  
  

  
  
  

